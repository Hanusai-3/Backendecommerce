package com.ecommerceapp.ecommerceapp.model;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class CartItem {
    // Getters and Setters
    private String productId;
    private int quantity;

}
